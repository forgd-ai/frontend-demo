#!/usr/bin/env bash
set -euo pipefail

input="$(cat)"

deny() {
  local reason="$1"
  if command -v jq >/dev/null 2>&1; then
    jq -nc --arg reason "$reason" '{
      hookSpecificOutput: {
        hookEventName: "PreToolUse",
        permissionDecision: "deny",
        permissionDecisionReason: $reason
      }
    }'
  else
    # Fallback: emit minimal JSON without jq so we can still deny if jq is missing.
    printf '{"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"deny","permissionDecisionReason":%s}}\n' \
      "\"$(printf '%s' "$reason" | sed 's/\\/\\\\/g; s/"/\\"/g')\""
  fi
  exit 0
}

if ! command -v jq >/dev/null 2>&1; then
  deny "preflight: jq is required to verify preflight stamps but is not installed. Install jq and try again."
fi

cmd="$(printf '%s' "$input" | jq -r '.tool_input.command // ""')"

if [[ "$cmd" != *"git push"* ]]; then
  exit 0
fi

short_sha="$(git rev-parse --short HEAD 2>/dev/null || echo "HEAD")"

note="$(git notes --ref=preflight show HEAD 2>/dev/null || true)"

if [[ -z "$note" ]]; then
  deny "preflight: commit ${short_sha} has not passed preflight checks. Run /preflight before pushing."
fi

verdict="$(printf '%s' "$note" | jq -r '.verdict // "unknown"')"

if [[ "$verdict" != "pass" ]]; then
  deny "preflight: commit ${short_sha} preflight verdict is '${verdict}', not 'pass'. Run /preflight before pushing."
fi

exit 0
