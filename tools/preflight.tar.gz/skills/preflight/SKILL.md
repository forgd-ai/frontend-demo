---
name: preflight
description: Run quality checks on HEAD before pushing
user-invocable: true
---

# /preflight

Gate the current HEAD behind automated quality checks. On PASS, stamps a `refs/notes/preflight` note on HEAD so `git push` is allowed by the pre-push hook and the in-Claude PreToolUse hook.

## Steps

1. **Check dependencies.** Run `${CLAUDE_PLUGIN_ROOT}/scripts/check-deps.sh`. If it exits non-zero, surface the output verbatim and stop — do not proceed to the orchestrator.

2. **Gather context.** In the user's repo (current working directory), capture:
   - `cwd` — absolute path from `pwd`
   - `branch` — `git branch --show-current`
   - `head_sha` — `git rev-parse --short HEAD`

   Run these in parallel.

3. **Spawn the orchestrator.** Use the Agent tool with `subagent_type: "preflight:orchestrator"`. Pass the three values above in the prompt, e.g.:

   > Run the full /preflight check on this repo.
   > cwd: `<cwd>`
   > branch: `<branch>`
   > HEAD: `<head_sha>`
   >
   > Return the final report and the verdict (PASS or FAIL).

   Wait for the agent to return. It writes `.preflight/report.md` and (on PASS) stamps HEAD via `scripts/stamp-note.sh`.

4. **Present the report.** Read `.preflight/report.md` and show the user a concise summary — verdict line, key FOCUS items from pr-summary, and any style violations.

5. **Next step.**
   - **PASS**: tell the user the commit is stamped and `git push` is now allowed. Suggest running `/preflight-pr` to generate a PR description from the same report (no re-checking needed).
   - **FAIL**: list the specific blockers (missing checks, style violations with file:line, risky diffs). Do not suggest pushing. Offer to help fix the highest-priority issue.
   - **NOTHING TO REVIEW**: tell the user this is the healthy outcome on a clean checkout — the current branch has no commits beyond the base branch, so there is no diff to gate. It confirms the plugin is installed and working. Suggest re-running after committing work on a feature branch. Never present this as a failure.

## Notes

- The orchestrator is the only component that writes the stamp. Never call `stamp-note.sh` directly from this skill.
- `.preflight/report.md` is the contract between `/preflight` and `/preflight-pr` — do not rewrite or delete it here.
- If the orchestrator reports `NOTHING TO REVIEW` (HEAD is at merge-base), relay it with the healthy-outcome framing from step 5 — it's a valid terminal state, not an error and not a FAIL.
